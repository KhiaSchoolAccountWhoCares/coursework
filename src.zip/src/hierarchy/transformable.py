from __future__ import annotations
from unittest.mock import Base
from pygame import Rect, Vector2

from utilities import *

#A simple transform which represents position, scale and rotation
class BaseTransform:
    def __init__(self) -> None:
        self.__position: Vector2 = Vector2(0,0)
        self.__scale: Vector2 = Vector2(1, 1)
        self.__rotation: float = 0
    #Neutral means that the scale and rotation are neutral
    def is_neutral(self)->bool:
        return self.__scale == Vector2(1, 1) and self.__rotation == 0
    def get_position(self)->Vector2:
        return self.__position
    def set_position(self, pos: Vector2)->None:
        self.__position = pos
    def get_scale(self)->Vector2:
        return self.__scale
    def set_scale(self, scale: Vector2)->None:
        self.__scale = scale
    def get_rotation(self)->float:
        return self.__rotation
    def set_rotation(self, rotation: float)->None:
        self.__rotation = rotation
    #Copies the values of another transform
    def copy_from(self, other: BaseTransform)->None:
        self.set_position(other.get_position())
        self.set_rotation(other.get_rotation())
        self.set_scale(other.get_scale())


#A transform that also allows for inheritance
class Transform(BaseTransform):
    def __init__(self) -> None:
        super().__init__()
        self.__position_event: GameEvent = GameEvent(0)
        self.__scale_event: GameEvent = GameEvent(0)
        self.__rotation_event: GameEvent = GameEvent(0)
        #The parent of this transform from which it will inherit
        self.__parent: Transform | None = None
        #Cache of global transform
        self.__is_cache_valid: bool = False
        self.__global_cache: BaseTransform = BaseTransform()
    #Whether this transform is an orphan or not.
    def __is_orphan(self)->bool:
        return (self.__parent is None)
    def set_parent_transform(self, parent: Transform | None = None)->None:
        self.__parent = parent
    def get_global_position(self)->Vector2:
        
    def get_position_event(self)->GameEvent:
        return self.__position_event
    def set_position(self, pos: Vector2)->None:
        if self.__position == pos:
            return
        super().set_position(pos)
        self.__position_event.fire()
    def get_scale(self)->Vector2:
        return self.__scale
    def get_scale_event(self)->GameEvent:
        return self.__scale_event
    def set_scale(self, scale: Vector2)->None:
        if self.__scale == scale:
            return
        self.__scale = scale
        self.__scale_event.fire()
    def get_rotation(self)->float:
        return self.__rotation
    def get_rotation_event(self)->GameEvent:
        return self.__rotation_event
    def set_rotation(self, rotation: float)->None:
        if self.__rotation == rotation:
            return
        self.__rotation = rotation
        self.__rotation_event.fire()
    def get_rect(self, size: Vector2)->Rect:
        return Rect(self.__position, Vector2(size * self.__scale))