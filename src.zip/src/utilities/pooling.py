class Poolable:
    def reset(self)->None:
        pass
    def on_spawn(self)->None:
        pass