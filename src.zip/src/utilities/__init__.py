from utilities.game_events import GameEvent, EventConnection
from utilities.pooling import Poolable