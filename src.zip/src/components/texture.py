class Texture:
    pass