from utilities import GameEvent

class HealthCounter:
    def __init__(self, max_health: int = 100) -> None:
        self.__health: int = max_health
        self.__max_health = max_health
        self.__damaged_event: GameEvent = GameEvent(2)#damage, self
        self.__healed_event: GameEvent = GameEvent(2)#amount, self
        self.__death_event: GameEvent = GameEvent(2)#damage, self
        self.__health_changed: GameEvent = GameEvent(2)#old health, self
        self.__invulnerable_event: GameEvent = GameEvent(1)#is invulnerable
        self.__revive_event: GameEvent = GameEvent(1)#new health
        self.__alive: bool = True
        self.__invulnerable: bool = False
        pass
    def get_current(self)->int:
        return self.__health
    
    def get_max_health(self)->int:
        return self.__max_health
    
    def set_health(self, value: int, silent: bool = False)->None:
        if value > 0:
            self.__health = value
    
    def set_health_max(self, max: int)->None:
        if max <= 0:
            return
        if max < self.__health:
            self.__health = max
        self.__max_health = max
        pass
    def damage(self, amount: int)->None:
        pass

    def heal(self, amount: int)->None:
        pass

    def kill(self)->None:
        if self.__alive:
            self.__alive = False
            self.__death_event.fire(0, self)
        pass

    def set_invulnerable(self, value: bool)->None:
        self.__invulnerable = value
        pass

    def get_invulnerable(self)->bool:
        return self.__invulnerable
    pass