from hierarchy.render_object import RenderObject


class Sprite(RenderObject):
    pass
