import gameplay
import gameplay.scenes
import hierarchy
 
import pygame
import ctypes
import sys
# Function to set DPI awareness on Windows def set_dpi_awareness():


def main():
    if sys.platform == 'win32':
        ctypes.windll.user32.SetProcessDPIAware()
    game = hierarchy.Game("Angular [TEST]")
    game.run(gameplay.scenes.GameField(game))
    pass

if __name__ == "__main__":
    main()