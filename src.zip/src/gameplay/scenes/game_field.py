from pygame import Color
from classes.background import Background
from classes.fps import Fps
from hierarchy import Game
from hierarchy import Scene
from gameplay.player import Player

class GameField(Scene):
    def __init__(self, game: Game) -> None:
        super().__init__()
        print("hi")
        self.__player = Player()
        self.__background = Background()
        self.__fps = Fps(game)
        self.__game = game
    def update(self, delta: float) -> None:
        self.__player.update(delta)
        self.__background.update(delta)
    def draw(self, delta: float) -> None:
        self.__player.draw(self.__game.get_screen(), delta)
        self.__fps.draw(self.__game.get_screen(), delta)
