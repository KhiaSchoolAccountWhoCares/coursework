import pygame
from pygame import Color, Surface, Vector2
from components.cached_renderer import CachedRenderer
from hierarchy.entity import Entity

class Player(Entity):
    def __init__(self):
        super().__init__()
        self.__sprite = CachedRenderer()
        self.__colour = Color("white")
    def draw(self, surface: Surface, delta: float)-> None:
        pygame.draw.circle(surface, self.__colour, self.get_position(), 32 * min(self._scale.x, self._scale.y))
        return super().draw(surface, delta)