#This script is meant to make making new modules be as simple as calling a single function.

import importlib
import importlib.util
import os
import os.path
from pathlib import Path

#todo: include additionals
def initialise_module(init_path: Path, additionals: list[Path] | None = None)->None: 
    if not init_path.is_absolute():
        raise Exception()
    module_directory = Path(os.path.dirname(init_path))
    for file in module_directory.glob("*.py"):
        if file.absolute() == init_path:
            continue
        importlib.import_module(str(file.absolute()))
    pass