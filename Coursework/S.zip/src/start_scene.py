from classes.scene import Scene

class StartScene(Scene):
    def load(self) -> None:
        return super().load()
    def update(self, delta: float) -> None:
        return super().update(delta)
    def draw(self, delta: float) -> None:
        return super().draw(delta)