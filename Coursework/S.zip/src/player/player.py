from classes.game_object import GameObject


class Player(GameObject):
    pass