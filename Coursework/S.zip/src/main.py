from classes.game import Game
from start_scene import StartScene


def main():
    game = Game()
    game.run(StartScene(game))
    pass

if __name__ == "__main__":
    main()