from typing import Any
import pygame 

class Game:
    _running: bool
    screen: pygame.Surface
    clock: pygame.time.Clock
    current_scene: Any
    clear_colour: pygame.Color

    def __init__(self):
        pygame.init()
        self._running = False
        self.screen = pygame.display.set_mode((480 * 2, 270 * 2))
        self.clock = pygame.time.Clock()
        self.current_scene = None
        self.clear_colour = pygame.Color("cornflowerblue")
    
    def _update(self, delta: float):
        self.current_scene.update(delta)
    
    def _draw(self, delta: float):
        self.screen.fill(self.clear_colour)
        self.current_scene.draw(delta)
        pygame.display.flip()
    
    def _execute_frame(self):
        delta_time = self.clock.tick(60) / 1000
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                self.quit()
        self._update(delta_time)
        self._draw(delta_time)
    
    def quit(self):
        self._running = False
    
    def run(self, scene):
        if self._running:
            return
        self.current_scene = scene
        self._running = True

        while self._running:
            self._execute_frame()
        