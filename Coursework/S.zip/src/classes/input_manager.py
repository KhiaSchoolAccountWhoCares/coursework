import pygame


class InputAction:
    pass

class InputManager:
    def assure_action(self, action: InputAction)->None:
        pass
    def is_action_pressed(self, action: str)->bool:
        return False
    def is_action_just_pressed(self, action: str)->bool:
        return False
    def get_vector(self, actions: tuple[str, str, str, str])->pygame.Vector2:
        return pygame.Vector2(0, 0)
    pass