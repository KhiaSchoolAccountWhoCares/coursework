from pygame import Surface
from classes.game import Game


class GameObject:
    game: Game
    render_target: Surface
    visible: bool
    active: bool
    def __init__(self, game):
        pass
    def _on_activity_change(self, new_state: bool)->None:
        pass
    def _on_visibility_change(self, new_visibility: bool)->None:
        pass
    def update(self, delta: float)->None:
        pass
    def draw(self, target: Surface, delta: float)->None:
        pass